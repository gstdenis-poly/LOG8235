// Fill out your copyright notice in the Description page of Project Settings.

#include "SDTFleeLocation.h"
#include "SoftDesignTraining.h"


// Sets default values
ASDTFleeLocation::ASDTFleeLocation()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASDTFleeLocation::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASDTFleeLocation::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

